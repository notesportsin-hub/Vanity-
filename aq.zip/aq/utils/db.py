import json
import os
import threading


class DB:
    """Tiny JSON storage (settings, tickets, noprefix list)."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.data = {}
        if os.path.exists(path):
            try:
                with open(path, encoding="utf-8") as f:
                    self.data = json.load(f)
            except (json.JSONDecodeError, OSError):
                self.data = {}

    def save(self):
        with self.lock:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()

    # per-guild settings
    def _guild(self, gid):
        return self.data.setdefault("guilds", {}).setdefault(str(gid), {})

    def gget(self, gid, key, default=None):
        return self._guild(gid).get(key, default)

    def gset(self, gid, key, value):
        self._guild(gid)[key] = value
        self.save()

    # tickets: {channel_id: {...}}
    def tickets(self):
        return self.data.setdefault("tickets", {})
