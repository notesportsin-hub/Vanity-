# Groot Bot

## Setup
1. `pip install -r requirements.txt`  (Python 3.9+)
2. `config.json` me `token` daalo (ya `DISCORD_TOKEN` env variable).
   `owner_ids` me apni Discord ID daalo, e.g. `[123456789012345678]`
3. Developer Portal -> Bot -> **Message Content Intent** aur **Server Members Intent** ON karo.
4. `python main.py`

## First-time server setup
- `.setlog #ticket-logs`
- `.setcategory <category id>`
- `.setsupport @StaffRole`
- `.ticketpanel #channel`

## Commands
- `.ticketpanel [#channel]`, `.close`, `.reopen`
- `.embed #channel`  -> embed builder (Edit Embed / Add Button / Send)
- `.noprefix add|remove|list @user` (owner only)

Emojis badalne ke liye sirf `emojis.py` edit karo.
Transcripts `transcripts/` folder me bhi save hote hain.
