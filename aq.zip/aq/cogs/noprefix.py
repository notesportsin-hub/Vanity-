import discord
from discord.ext import commands

from emojis import E


class NoPrefix(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def _list(self):
        return self.bot.db.get("noprefix", [])

    @commands.group(name="noprefix", invoke_without_command=True)
    @commands.is_owner()
    async def noprefix(self, ctx):
        p = ctx.prefix or "."
        await ctx.send(f"Usage: `{p}noprefix add @user`, `{p}noprefix remove @user`, `{p}noprefix list`")

    @noprefix.command(name="add")
    @commands.is_owner()
    async def np_add(self, ctx, user: discord.User):
        users = self._list()
        if user.id in users:
            return await ctx.send(f"{E.general.warn} {user.mention} already has no-prefix.")
        users.append(user.id)
        self.bot.db.set("noprefix", users)
        await ctx.send(f"{E.general.success} No-prefix enabled for {user.mention}.")

    @noprefix.command(name="remove")
    @commands.is_owner()
    async def np_remove(self, ctx, user: discord.User):
        users = self._list()
        if user.id not in users:
            return await ctx.send(f"{E.general.warn} {user.mention} is not in the no-prefix list.")
        users.remove(user.id)
        self.bot.db.set("noprefix", users)
        await ctx.send(f"{E.general.success} No-prefix removed for {user.mention}.")

    @noprefix.command(name="list")
    @commands.is_owner()
    async def np_list(self, ctx):
        users = self._list()
        text = "\n".join(f"<@{u}> (`{u}`)" for u in users) or "Nobody yet."
        await ctx.send(embed=discord.Embed(title="No-Prefix Users", description=text, color=discord.Color.from_str(self.bot.config.get("embed_color", "#2b2d31"))))


async def setup(bot):
    await bot.add_cog(NoPrefix(bot))
