import asyncio
import datetime
import html
import os
import re

import discord
from discord.ext import commands

from emojis import E

CATEGORIES = {
    "prize_claim": dict(label="Prize Claim", desc="Claim your prize", emoji=E.category.prize_claim, short="prize"),
    "buy": dict(label="Buy", desc="Purchase a product", emoji=E.category.buy, short="buy"),
    "partnership": dict(label="Partnership", desc="Partner with us", emoji=E.category.partnership, short="partner"),
    "general_support": dict(label="General Support", desc="Any other help", emoji=E.category.general_support, short="support"),
}

# categories that get the 3 questions (product / payment / quantity)
QUESTION_CATEGORIES = {"buy"}
BUY_QUESTIONS = ["What product you want?", "Your payment method", "Quantity"]


# ----------------------------------------------------------------- helpers
def base_embed(client, title=None, description=None):
    e = discord.Embed(title=title, description=description, color=discord.Color.from_str(client.config.get("embed_color", "#2b2d31")))
    if client.config.get("footer"):
        e.set_footer(text=client.config["footer"])
    return e


def is_staff(client, member):
    if not isinstance(member, discord.Member):
        return False
    perms = member.guild_permissions
    if perms.administrator or perms.manage_channels:
        return True
    role_id = client.db.gget(member.guild.id, "support_role")
    return bool(role_id and any(r.id == role_id for r in member.roles))


async def build_transcript(channel, ticket):
    rows = []
    async for m in channel.history(limit=None, oldest_first=True):
        ts = m.created_at.strftime("%Y-%m-%d %H:%M:%S UTC")
        body = html.escape(m.content).replace("\n", "<br>")
        extra = ""
        for a in m.attachments:
            extra += f'<div class="att">📎 <a href="{html.escape(a.url)}">{html.escape(a.filename)}</a></div>'
        for em in m.embeds:
            parts = [x for x in (em.title, em.description) if x]
            for f in em.fields:
                parts.append(f"{f.name}: {f.value}")
            if parts:
                extra += '<div class="emb">' + "<br>".join(html.escape(p).replace("\n", "<br>") for p in parts) + "</div>"
        rows.append(
            f'<div class="msg"><img src="{html.escape(m.author.display_avatar.url)}">'
            f'<div><span class="name">{html.escape(m.author.display_name)}</span>'
            f'<span class="ts">{ts}</span><div>{body}</div>{extra}</div></div>'
        )
    page = """<!DOCTYPE html><html><head><meta charset="utf-8"><title>__TITLE__</title><style>
body{background:#313338;color:#dbdee1;font-family:Arial,sans-serif;margin:0;padding:20px}
h2{margin:0 0 4px}.sub{color:#949ba4;margin-bottom:20px}
.msg{display:flex;gap:12px;margin:10px 0}.msg img{width:40px;height:40px;border-radius:50%}
.name{font-weight:bold;color:#fff}.ts{color:#949ba4;font-size:12px;margin-left:8px}
.att a{color:#00a8fc}.emb{border-left:4px solid #4e5058;background:#2b2d31;padding:8px;margin-top:4px;border-radius:4px}
</style></head><body><h2>__TITLE__</h2><div class="sub">Category: __CAT__ • Messages: __COUNT__</div>__ROWS__</body></html>"""
    page = (page.replace("__TITLE__", html.escape(f"#{channel.name}"))
            .replace("__CAT__", html.escape(CATEGORIES.get(ticket["category"], {}).get("label", "-")))
            .replace("__COUNT__", str(len(rows)))
            .replace("__ROWS__", "".join(rows)))
    folder = os.path.join("transcripts", str(channel.guild.id))
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    path = os.path.join(folder, f"transcript-{channel.name}-{stamp}.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(page)
    return path


async def send_transcript(client, channel, ticket, closer):
    path = await build_transcript(channel, ticket)
    guild = channel.guild
    owner = guild.get_member(ticket["owner"]) or client.get_user(ticket["owner"])
    cat = CATEGORIES.get(ticket["category"], {}).get("label", "-")

    dm_ok = False
    if owner:
        e = base_embed(client, f"{E.ticket.transcript} Ticket Transcript",
                       f"Your ticket **#{channel.name}** in **{guild.name}** was closed.\nCategory: **{cat}**")
        try:
            await owner.send(embed=e, file=discord.File(path))
            dm_ok = True
        except (discord.Forbidden, discord.HTTPException):
            pass

    log_id = client.db.gget(guild.id, "log_channel")
    log_ch = guild.get_channel(log_id) if log_id else None
    if log_ch:
        e = base_embed(client, f"{E.ticket.close} Ticket Closed")
        e.add_field(name="Ticket", value=f"#{channel.name}", inline=True)
        e.add_field(name="Category", value=cat, inline=True)
        e.add_field(name="Opened by", value=f"<@{ticket['owner']}>", inline=True)
        e.add_field(name="Closed by", value=closer.mention, inline=True)
        e.add_field(name="Transcript DM", value="Sent" if dm_ok else "Failed (DMs closed)", inline=True)
        try:
            await log_ch.send(embed=e, file=discord.File(path))
        except discord.HTTPException:
            pass


# ----------------------------------------------------------- core actions
async def close_ticket(client, channel, actor):
    t = client.db.tickets().get(str(channel.id))
    if not t:
        return "This is not a ticket channel."
    if t["status"] == "closed":
        return "This ticket is already closed."
    if actor.id != t["owner"] and not is_staff(client, actor):
        return "You can't close this ticket."
    t["status"] = "closed"
    t["closed_by"] = actor.id
    client.db.save()
    owner = channel.guild.get_member(t["owner"])
    if owner:
        try:
            await channel.set_permissions(owner, view_channel=True, send_messages=False, read_message_history=True)
        except discord.HTTPException:
            pass
    await send_transcript(client, channel, t, actor)
    e = base_embed(client, f"{E.ticket.close} Ticket Closed",
                   f"Closed by {actor.mention}.\nTranscript saved and sent to the ticket owner and the log channel.")
    await channel.send(embed=e, view=ClosedControlView())
    return None


async def reopen_ticket(client, channel, actor):
    t = client.db.tickets().get(str(channel.id))
    if not t:
        return "This is not a ticket channel."
    if t["status"] != "closed":
        return "This ticket is already open."
    if actor.id != t["owner"] and not is_staff(client, actor):
        return "You can't reopen this ticket."
    t["status"] = "open"
    t.pop("closed_by", None)
    client.db.save()
    owner = channel.guild.get_member(t["owner"])
    if owner:
        try:
            await channel.set_permissions(owner, view_channel=True, send_messages=True, read_message_history=True, attach_files=True)
        except discord.HTTPException:
            pass
    e = base_embed(client, f"{E.ticket.reopen} Ticket Reopened", f"Reopened by {actor.mention}.")
    await channel.send(content=f"<@{t['owner']}>", embed=e, view=TicketControlView())
    return None


# -------------------------------------------------------------------- views
class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close", style=discord.ButtonStyle.danger, emoji=E.ticket.close, custom_id="groot:ticket:close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        err = await close_ticket(interaction.client, interaction.channel, interaction.user)
        if err:
            await interaction.followup.send(err, ephemeral=True)


class ClosedControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Reopen", style=discord.ButtonStyle.success, emoji=E.ticket.reopen, custom_id="groot:ticket:reopen")
    async def reopen(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        err = await reopen_ticket(interaction.client, interaction.channel, interaction.user)
        if err:
            return await interaction.followup.send(err, ephemeral=True)
        try:
            await interaction.message.edit(view=None)
        except discord.HTTPException:
            pass

    @discord.ui.button(label="Delete", style=discord.ButtonStyle.secondary, emoji=E.ticket.delete, custom_id="groot:ticket:delete")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        client = interaction.client
        if not is_staff(client, interaction.user):
            return await interaction.response.send_message("Only staff can delete tickets.", ephemeral=True)
        await interaction.response.send_message(f"{E.ticket.delete} Deleting this ticket in 5 seconds...")
        await asyncio.sleep(5)
        client.db.tickets().pop(str(interaction.channel.id), None)
        client.db.save()
        try:
            await interaction.channel.delete(reason=f"Ticket deleted by {interaction.user}")
        except discord.HTTPException:
            pass


class TicketModal(discord.ui.Modal):
    def __init__(self, key):
        super().__init__(title=f"{CATEGORIES[key]['label']} Ticket"[:45])
        self.key = key
        self.inputs = []
        if key in QUESTION_CATEGORIES:
            for q in BUY_QUESTIONS:
                self.inputs.append((q, discord.ui.TextInput(label=q, max_length=100)))
        else:
            self.inputs.append(("How can we help you?", discord.ui.TextInput(label="How can we help you?", style=discord.TextStyle.paragraph, max_length=1000)))
        for _, i in self.inputs:
            self.add_item(i)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        client, guild, user = interaction.client, interaction.guild, interaction.user
        answers = [(q, i.value) for q, i in self.inputs]

        cat_id = client.db.gget(guild.id, "ticket_category")
        category = guild.get_channel(cat_id) if cat_id else None
        if not isinstance(category, discord.CategoryChannel):
            category = None
        role = guild.get_role(client.db.gget(guild.id, "support_role") or 0)

        ow = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, attach_files=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True, read_message_history=True, embed_links=True, attach_files=True),
        }
        if role:
            ow[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True, attach_files=True)

        name = re.sub(r"[^a-z0-9-]", "", f"{CATEGORIES[self.key]['short']}-{user.name}".lower()) or f"ticket-{user.id}"
        try:
            channel = await guild.create_text_channel(name[:90], category=category, overwrites=ow, reason=f"Ticket by {user}")
        except discord.HTTPException as err:
            return await interaction.followup.send(f"{E.general.error} Couldn't create ticket: {err}", ephemeral=True)

        client.db.tickets()[str(channel.id)] = {
            "guild": guild.id, "owner": user.id, "category": self.key, "status": "open",
            "answers": answers, "created": datetime.datetime.utcnow().isoformat(),
        }
        client.db.save()

        e = base_embed(client, f"{E.ticket.open} {CATEGORIES[self.key]['label']}",
                       f"Welcome {user.mention}! Staff will be with you shortly.")
        for q, a in answers:
            e.add_field(name=q, value=a, inline=False)
        content = user.mention + (f" {role.mention}" if role else "")
        await channel.send(content=content, embed=e, view=TicketControlView(),
                           allowed_mentions=discord.AllowedMentions(users=True, roles=True))
        await interaction.followup.send(f"{E.general.success} Ticket created: {channel.mention}", ephemeral=True)


class CategorySelect(discord.ui.Select):
    def __init__(self):
        options = [discord.SelectOption(label=v["label"], value=k, description=v["desc"], emoji=v["emoji"]) for k, v in CATEGORIES.items()]
        super().__init__(placeholder="Select a category to open a ticket...", options=options, custom_id="groot:ticket:select")

    async def callback(self, interaction: discord.Interaction):
        client, guild, user = interaction.client, interaction.guild, interaction.user
        key = self.values[0]
        # one open ticket per user
        for cid, t in list(client.db.tickets().items()):
            if t["guild"] == guild.id and t["owner"] == user.id and t["status"] == "open":
                ch = guild.get_channel(int(cid))
                if ch:
                    return await interaction.response.send_message(f"{E.general.warn} You already have an open ticket: {ch.mention}", ephemeral=True)
                client.db.tickets().pop(cid, None)
                client.db.save()
        await interaction.response.send_modal(TicketModal(key))
        try:  # reset dropdown selection
            await interaction.message.edit(view=TicketPanelView())
        except discord.HTTPException:
            pass


class TicketPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(CategorySelect())


# ---------------------------------------------------------------------- cog
class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketControlView())
        self.bot.add_view(ClosedControlView())

    @commands.command(name="ticketpanel")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def ticketpanel(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel
        e = base_embed(self.bot, f"{E.ticket.open} Support Tickets",
                       "Select a category below to open a ticket.\n\n" +
                       "\n".join(f"{v['emoji']} **{v['label']}** – {v['desc']}" for v in CATEGORIES.values()))
        await channel.send(embed=e, view=TicketPanelView())
        if channel != ctx.channel:
            await ctx.send(f"{E.general.success} Panel sent to {channel.mention}")

    @commands.command(name="close")
    @commands.guild_only()
    async def close(self, ctx):
        err = await close_ticket(self.bot, ctx.channel, ctx.author)
        if err:
            await ctx.send(f"{E.general.error} {err}")

    @commands.command(name="reopen")
    @commands.guild_only()
    async def reopen(self, ctx):
        err = await reopen_ticket(self.bot, ctx.channel, ctx.author)
        if err:
            await ctx.send(f"{E.general.error} {err}")

    @commands.command(name="setlog")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def setlog(self, ctx, channel: discord.TextChannel):
        self.bot.db.gset(ctx.guild.id, "log_channel", channel.id)
        await ctx.send(f"{E.general.success} Ticket log channel set to {channel.mention}")

    @commands.command(name="setcategory")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def setcategory(self, ctx, category: discord.CategoryChannel):
        self.bot.db.gset(ctx.guild.id, "ticket_category", category.id)
        await ctx.send(f"{E.general.success} Tickets will be created under **{category.name}**")

    @commands.command(name="setsupport")
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def setsupport(self, ctx, role: discord.Role):
        self.bot.db.gset(ctx.guild.id, "support_role", role.id)
        await ctx.send(f"{E.general.success} Support role set to {role.mention}", allowed_mentions=discord.AllowedMentions.none())


async def setup(bot):
    await bot.add_cog(Tickets(bot))
