import discord
from discord.ext import commands

from emojis import E

MAX_BUTTONS = 10


class EmbedState:
    def __init__(self):
        self.title = ""
        self.description = ""
        self.color = ""
        self.footer = ""
        self.image = ""
        self.buttons = []  # (label, url, emoji)


def is_url(v):
    return v.startswith("http://") or v.startswith("https://")


class EmbedModal(discord.ui.Modal):
    def __init__(self, builder):
        super().__init__(title="Edit Embed")
        self.builder = builder
        s = builder.state
        self.f_title = discord.ui.TextInput(label="Title", required=False, max_length=256, default=s.title or None)
        self.f_desc = discord.ui.TextInput(label="Description", style=discord.TextStyle.paragraph, required=False, max_length=4000, default=s.description or None)
        self.f_color = discord.ui.TextInput(label="Color (hex, e.g. #5865F2)", required=False, max_length=7, default=s.color or None)
        self.f_footer = discord.ui.TextInput(label="Footer", required=False, max_length=2048, default=s.footer or None)
        self.f_image = discord.ui.TextInput(label="Image URL", required=False, max_length=500, default=s.image or None)
        for f in (self.f_title, self.f_desc, self.f_color, self.f_footer, self.f_image):
            self.add_item(f)

    async def on_submit(self, interaction: discord.Interaction):
        s = self.builder.state
        s.title = self.f_title.value.strip()
        s.description = self.f_desc.value.strip()
        s.color = self.f_color.value.strip()
        s.footer = self.f_footer.value.strip()
        image = self.f_image.value.strip()
        s.image = image if is_url(image) else ""
        await self.builder.refresh(interaction)


class ButtonModal(discord.ui.Modal):
    def __init__(self, builder):
        super().__init__(title="Add Link Button")
        self.builder = builder
        self.f_label = discord.ui.TextInput(label="Button label", max_length=80)
        self.f_url = discord.ui.TextInput(label="Button link (https://...)", max_length=500)
        self.f_emoji = discord.ui.TextInput(label="Emoji (optional)", required=False, max_length=64)
        for f in (self.f_label, self.f_url, self.f_emoji):
            self.add_item(f)

    async def on_submit(self, interaction: discord.Interaction):
        url = self.f_url.value.strip()
        if not is_url(url):
            return await interaction.response.send_message(f"{E.general.error} Link must start with http:// or https://", ephemeral=True)
        if len(self.builder.state.buttons) >= MAX_BUTTONS:
            return await interaction.response.send_message(f"{E.general.error} Max {MAX_BUTTONS} buttons.", ephemeral=True)
        self.builder.state.buttons.append((self.f_label.value.strip(), url, self.f_emoji.value.strip()))
        await self.builder.refresh(interaction)


class EmbedBuilderView(discord.ui.View):
    def __init__(self, bot, author, channel):
        super().__init__(timeout=900)
        self.bot = bot
        self.author = author
        self.channel = channel
        self.state = EmbedState()

    async def interaction_check(self, interaction: discord.Interaction):
        if interaction.user.id != self.author.id:
            await interaction.response.send_message("Only the command author can use this.", ephemeral=True)
            return False
        return True

    def default_color(self):
        return discord.Color.from_str(self.bot.config.get("embed_color", "#2b2d31"))

    def build(self, preview=False):
        s = self.state
        try:
            color = discord.Color(int(s.color.lstrip("#"), 16)) if s.color else self.default_color()
        except ValueError:
            color = self.default_color()
        e = discord.Embed(title=s.title or None, description=s.description or None, color=color)
        if s.footer:
            e.set_footer(text=s.footer)
        if s.image:
            e.set_image(url=s.image)
        if preview and not (s.title or s.description or s.image):
            e.description = "*Empty embed — click **Edit Embed** to start.*"
        return e

    def link_view(self):
        if not self.state.buttons:
            return None
        v = discord.ui.View()
        for label, url, emoji in self.state.buttons:
            v.add_item(discord.ui.Button(label=label, url=url, emoji=emoji or None, style=discord.ButtonStyle.link))
        return v

    def status(self):
        lines = [f"Preview • will be sent to {self.channel.mention}"]
        for i, (label, url, _) in enumerate(self.state.buttons, 1):
            lines.append(f"{E.embed.button} {i}. **{label}** → {url}")
        return "\n".join(lines)

    async def refresh(self, interaction):
        await interaction.response.edit_message(content=self.status(), embed=self.build(True), view=self)

    @discord.ui.button(label="Edit Embed", style=discord.ButtonStyle.primary, emoji=E.embed.edit)
    async def edit(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(EmbedModal(self))

    @discord.ui.button(label="Add Button", style=discord.ButtonStyle.secondary, emoji=E.embed.button)
    async def add_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ButtonModal(self))

    @discord.ui.button(label="Clear Buttons", style=discord.ButtonStyle.secondary, emoji=E.embed.clear)
    async def clear(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.state.buttons.clear()
        await self.refresh(interaction)

    @discord.ui.button(label="Send", style=discord.ButtonStyle.success, emoji=E.embed.send)
    async def send(self, interaction: discord.Interaction, button: discord.ui.Button):
        s = self.state
        if not (s.title or s.description or s.image):
            return await interaction.response.send_message(f"{E.general.warn} Embed is empty.", ephemeral=True)
        kwargs = {"embed": self.build()}
        lv = self.link_view()
        if lv:
            kwargs["view"] = lv
        try:
            await self.channel.send(**kwargs)
        except discord.HTTPException as err:
            return await interaction.response.send_message(f"{E.general.error} Couldn't send: {err}", ephemeral=True)
        self.stop()
        await interaction.response.edit_message(content=f"{E.general.success} Embed sent to {self.channel.mention}", embed=None, view=None)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.danger, emoji=E.embed.cancel)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.stop()
        await interaction.response.edit_message(content="Cancelled.", embed=None, view=None)


class Embeds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="embed")
    @commands.guild_only()
    @commands.has_permissions(manage_messages=True)
    async def embed(self, ctx, channel: discord.TextChannel):
        perms = channel.permissions_for(ctx.guild.me)
        if not (perms.send_messages and perms.embed_links):
            return await ctx.send(f"{E.general.error} I need Send Messages + Embed Links in {channel.mention}.")
        view = EmbedBuilderView(self.bot, ctx.author, channel)
        await ctx.send(content=view.status(), embed=view.build(True), view=view)


async def setup(bot):
    await bot.add_cog(Embeds(bot))
