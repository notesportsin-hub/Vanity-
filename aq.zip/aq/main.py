import json
import logging
import os
import sys

import discord
from discord.ext import commands

from emojis import E
from utils.db import DB

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("groot")

with open("config.json", encoding="utf-8") as f:
    CONFIG = json.load(f)

TOKEN = os.getenv("DISCORD_TOKEN") or CONFIG.get("token")
if not TOKEN or TOKEN == "YOUR_BOT_TOKEN_HERE":
    sys.exit("config.json me apna bot token daalo (ya DISCORD_TOKEN env variable set karo).")


def get_prefix(bot, message):
    prefixes = commands.when_mentioned_or(bot.config.get("prefix", "."))(bot, message)
    allowed = set(bot.db.get("noprefix", [])) | set(bot.config.get("owner_ids", []))
    if message.author.id in allowed:
        prefixes.append("")  # no-prefix users
    return prefixes


class Groot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(
            command_prefix=get_prefix,
            intents=intents,
            help_command=None,
            case_insensitive=True,
            owner_ids=set(CONFIG.get("owner_ids", [])) or None,
        )
        self.config = CONFIG
        self.db = DB("data/db.json")

    async def setup_hook(self):
        for ext in ("cogs.tickets", "cogs.embeds", "cogs.noprefix"):
            await self.load_extension(ext)

    async def on_ready(self):
        log.info("Logged in as %s (%s)", self.user, self.user.id)

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingPermissions):
            return await ctx.send(f"{E.general.error} You don't have permission for this.")
        if isinstance(error, commands.NotOwner):
            return await ctx.send(f"{E.general.error} Owner only command.")
        if isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument)):
            return await ctx.send(f"{E.general.warn} Usage: `{ctx.prefix}{ctx.command.qualified_name} {ctx.command.signature}`")
        if isinstance(error, commands.NoPrivateMessage):
            return
        log.exception("Command error", exc_info=error)


bot = Groot()


@bot.command(name="help")
async def help_cmd(ctx):
    p = bot.config.get("prefix", ".")
    e = discord.Embed(title="Groot • Help", color=discord.Color.from_str(bot.config.get("embed_color", "#2b2d31")))
    e.add_field(name=f"{E.ticket.open} Tickets", value=(
        f"`{p}ticketpanel [#channel]` – send ticket panel\n"
        f"`{p}close` / `{p}reopen` – close or reopen a ticket\n"
        f"`{p}setlog #channel` – ticket log channel\n"
        f"`{p}setcategory <id>` – category where tickets are created\n"
        f"`{p}setsupport @role` – support staff role"), inline=False)
    e.add_field(name=f"{E.embed.send} Embed", value=f"`{p}embed #channel` – embed builder with buttons", inline=False)
    e.add_field(name=f"{E.general.dot} No-Prefix", value=f"`{p}noprefix add/remove/list` – owner only", inline=False)
    if bot.config.get("footer"):
        e.set_footer(text=bot.config["footer"])
    await ctx.send(embed=e)


if __name__ == "__main__":
    bot.run(TOKEN)
