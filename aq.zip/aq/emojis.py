"""
ALL EMOJIS LIVE HERE.
Change an emoji once in this file and it updates everywhere in the bot.
Custom emoji format: "<:name:123456789012345678>"  (animated: "<a:name:123456789012345678>")
"""
from types import SimpleNamespace as NS

E = NS(
    general=NS(
        success="✅",
        error="❌",
        warn="⚠️",
        dot="🟢",
        arrow="➡️",
    ),
    ticket=NS(
        open="🎫",
        close="🔒",
        reopen="🔓",
        delete="🗑️",
        transcript="📄",
        user="👤",
        category="📂",
    ),
    # ticket categories (shown in the dropdown)
    category=NS(
        prize_claim="🎁",
        buy="🛒",
        partnership="🤝",
        general_support="💬",
    ),
    embed=NS(
        edit="✏️",
        button="🔘",
        clear="🧹",
        send="📨",
        cancel="✖️",
    ),
)
